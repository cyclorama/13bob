     __                            .-'''-.               
...-'  |`. ..-'''-.               '   _    \             
|      |  |\.-'''\ \   /|       /   /` '.   \ /|         
....   |  |       | |  ||      .   |     \  ' ||         
  -|   |  |    __/ /   ||      |   '      |  '||         
   |   |  |   |_  '.   ||  __  \    \     / / ||  __     
...'   `--'      `.  \ ||/'__ '.`.   ` ..' /  ||/'__ '.  
|         |`.      \ '.|:/`  '. '  '-...-'`   |:/`  '. ' 
` --------\ |       , |||     | |             ||     | | 
 `---------'        | |||\    / '             ||\    / ' 
                   / ,'|/\'..' /              |/\'..' /  
           -....--'  / '  `'-'`               '  `'-'`   
           `.. __..-'                                     
+-------------------------------------------------------+
|	Author: ebob										|
|	Description: Space physics game.					|
+-------------------------------------------------------+

1. Run executable (install the C++ redistributable packages if you get errors pertaining to that)
2. Play!

+--------------+
|   Controls   |
|              |
| MOUSE = AIM  |
| F 	= FIRE |
| ESC   = QUIT |
|			   |
+--------------+

Use the gravitational pull of the planets to hit the target. The longer the trajectory to the target, the higher the score.