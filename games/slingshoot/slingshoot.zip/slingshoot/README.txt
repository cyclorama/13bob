     __                            .-'''-.               
...-'  |`. ..-'''-.               '   _    \             
|      |  |\.-'''\ \   /|       /   /` '.   \ /|         
....   |  |       | |  ||      .   |     \  ' ||         
  -|   |  |    __/ /   ||      |   '      |  '||         
   |   |  |   |_  '.   ||  __  \    \     / / ||  __     
...'   `--'      `.  \ ||/'__ '.`.   ` ..' /  ||/'__ '.  
|         |`.      \ '.|:/`  '. '  '-...-'`   |:/`  '. ' 
` --------\ |       , |||     | |             ||     | | 
 `---------'        | |||\    / '             ||\    / ' 
                   / ,'|/\'..' /              |/\'..' /  
           -....--'  / '  `'-'`               '  `'-'`   
           `.. __..-'                                     
+-------------------------------------------------------+
|	Author: ebob										|
|	Description: Space-physics game.					|
|	Demo: https://www.youtube.com/watch?v=sdxegudH0-0	|
+-------------------------------------------------------+

+-----------------+
|    Controls     |
|                 |
| MOUSE = AIM     |
| F 	= FIRE 	  |
| R     = RESTART |
| ESC   = QUIT    |
|			      |
+-----------------+

Run executable (install the C++ redistributable packages if you get errors pertaining to that). Use the gravitational pull of the planets to hit the target. The longer the trajectory to the target, the higher the score.