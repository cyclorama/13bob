                       :
                       :
                       :
                       :
        .              :
         '.            :           .'
           '.          :         .'
             '.   .-""""""-.   .'                                   .'':
               '."          ".'                               .-""""-.'         .---.          .----.        .-"""-.
                :            :                _    _        ."     .' ".    ..."     "...    ."      ".    ."       ".
        .........            .........    o  (_)  (_)  ()   :    .'    :   '..:.......:..'   :        :    :         :   o
                :            :                              :  .'      :       '.....'       '.      .'    '.       .'
                 :          :                             .'.'.      .'                        `''''`        `'''''`
                  '........'                              ''   ``````
                 .'    :   '.
               .'      :     '.
             .'        :       '.
           .'          :         '.
                       :
                       :
                       :
                       :

Use the gravitational pull of the planets to hit the target.

MOUSE = AIM
F = FIRE
R = RESTART
ESC = QUIT
(SCORE = TRAJECTORY DISTANCE)
